

**CounterFlowPOS Lite**

**International End User License Agreement (EULA)**

**ACCEPT ALL CONDITIONS FIRST**

**Last Updated: 11th Jan 2026**

**IMPORTANT — READ CAREFULLY.**

This End User License Agreement (“Agreement” or “EULA”) is a legally binding agreement between you (“User,” “You,” or “Your”), regardless of country of residence, and CorpToolKit Inc, an Illinois corporation, United States of America (“CorpToolKit,” “Licensor,” “We,” or “Us”).

BY CLICKING “I ACCEPT,” INSTALLING, OR USING THE SOFTWARE, YOU AGREE TO BE LEGALLY BOUND BY THIS AGREEMENT.

IF YOU DO NOT AGREE, DO NOT INSTALL OR USE THE SOFTWARE.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

1\. Licensor

CorpToolKit Inc

State of Incorporation: Illinois, USA

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2\. License Grant 

Subject to your compliance with this Agreement, CorpToolKit Inc grants you a limited, non-exclusive, non-transferable, revocable, royalty-free license to download, install, and use CounterFlowPOS Lite (“Software”) solely for personal, educational, evaluation, or small business purposes on systems you own or control.

This license is granted worldwide, subject to applicable export laws and local regulations, and applies only to the Lite version of the Software.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3\. Free Distribution and Local Installation

CounterFlowPOS Lite is distributed free of charge via:

https://counterflowpos.com

The Software is designed for local desktop installation. CorpToolKit Inc does not provide hosting, cloud services, backups, monitoring, or operational support for the Lite version.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4\. No Partnership or Contractual Relationship

You acknowledge and agree that:

•	This EULA does not create a partnership, joint venture, employment, agency, fiduciary, service, or customer relationship

•	CorpToolKit Inc is not entering into any commercial or services agreement with you

•	No representations or obligations exist beyond those expressly stated in this Agreement

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5\. User Responsibility and Compliance with Local Laws

You are solely responsible for:

•	Installation, configuration, operation, and maintenance of the Software

•	All hardware, operating systems, networks, and security controls

•	All data processed, stored, or generated using the Software

•	Compliance with local, national, and international laws, including but not limited to data protection, privacy, tax, labor, and industry regulations

CorpToolKit Inc makes no representation that the Software complies with laws or regulations outside the United States.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6\. Security and Local Data Access Disclaimer

CorpToolKit Inc has implemented reasonable industry-standard practices, including user accounts, role-based access controls, and permission restrictions within the Software.

However, you acknowledge and agree that:

•	The Software operates as a locally installed system

•	Individuals with sufficient operating-system or file-system access may be able to access local datasets or archives outside the application

•	CorpToolKit Inc does not guarantee protection against unauthorized access, misuse, extraction, or loss of data resulting from local system access, misconfiguration, or user actions

You assume all risks related to local data storage, access, and security.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7\. Reservation of Rights; Future Commercialization

CorpToolKit Inc expressly reserves all rights not granted to you under this Agreement.

You acknowledge and agree that:

•	CorpToolKit Inc may, at its sole discretion, modify, restrict, discontinue, rebrand, or convert CounterFlowPOS Lite (or any future version thereof) into a paid, subscription-based, or commercially licensed product

•	Any such change shall not retroactively affect licenses already granted for versions distributed prior to such change, unless expressly stated

•	Continued use of future versions may require acceptance of new or updated license terms

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

8\. No Warranty (International Disclaimer)

THE SOFTWARE IS PROVIDED “AS IS” AND “AS AVAILABLE.”

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, CORPTOOLKIT INC DISCLAIMS ALL WARRANTIES, WHETHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, INCLUDING BUT NOT LIMITED TO:

•	MERCHANTABILITY

•	FITNESS FOR A PARTICULAR PURPOSE

•	NON-INFRINGEMENT

•	ACCURACY, AVAILABILITY, OR RELIABILITY

•	DATA SECURITY, DATA INTEGRITY, OR ERROR-FREE OPERATION

Some jurisdictions do not allow certain warranty exclusions; in such cases, exclusions apply to the maximum extent permitted by law.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

9\. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW:

IN NO EVENT SHALL CORPTOOLKIT INC BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO:

•	DATA LOSS OR CORRUPTION

•	SECURITY BREACHES

•	HARDWARE OR SOFTWARE FAILURE

•	BUSINESS INTERRUPTION

•	LOSS OF PROFITS, REVENUE, OR BUSINESS OPPORTUNITIES

REGARDLESS OF THE LEGAL THEORY, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

10\. Indemnification

You agree to indemnify, defend, and hold harmless CorpToolKit Inc from any claims, damages, losses, liabilities, costs, and expenses (including reasonable attorneys’ fees) arising from:

•	Your use or misuse of the Software

•	Your data, content, or business operations

•	Your violation of this Agreement or applicable law

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

11\. Export Controls and Sanctions

You represent and warrant that:

•	You are not located in, under the control of, or a national or resident of any country subject to U.S. embargoes or sanctions

•	You will comply with all applicable U.S. export control laws, regulations, and international trade restrictions

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

12\. Enterprise Use and Upgrades

CounterFlowPOS Lite is not intended for enterprise-grade, regulated, or mission-critical environments.

Users requiring enterprise functionality, advanced security, centralized management, or professional support should contact CorpToolKit Inc regarding CounterFlowPOS Pro.

📧 Sales Contact: admin@corptoolkit.com

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

13\. Termination

This Agreement is effective until terminated. CorpToolKit Inc may terminate this Agreement immediately upon your breach. Upon termination, you must cease all use and uninstall the Software.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

14\. Governing Law

This Agreement shall be governed by and construed in accordance with the laws of the State of Illinois, United States of America, without regard to conflict-of-law principles.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

15\. Exclusive Venue and Jurisdiction

Any dispute, claim, or legal proceeding arising out of or relating to this Agreement or the Software shall be brought exclusively in the state or federal courts located in the State of Illinois, USA.

You irrevocably consent to the personal jurisdiction and venue of such courts and waive any objection based on forum non conveniens or similar doctrines.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

16\. Severability

If any provision of this Agreement is held unenforceable, the remaining provisions shall remain in full force and effect.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

17\. Waiver

No failure or delay by CorpToolKit Inc in enforcing any right shall constitute a waiver.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

18\. Survival

Sections relating to warranty disclaimers, limitation of liability, indemnification, governing law, venue, jurisdiction, and reservation of rights shall survive termination.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

19\. Entire Agreement

This Agreement constitutes the entire agreement between you and CorpToolKit Inc regarding CounterFlowPOS Lite and supersedes all prior communications or understandings.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Installer / First-Run** 

**By installing or running,” you confirm that you have read, understood, and agree to be legally bound by the CounterFlowPOS Lite End User License Agreement. If you do not agree, exit ,uninstall and delete the software immediately.**





